# Formation_Consensus_basic
A basic version for robot formation consensus and obstacle avoidance by MATLAB.


You can just run consensus_APF.m or consensus_DWA.m

Before that, you need right click subfun and add the select folders and subfolders into the path!

FYI: if it helps, there is a tutorial in Chinese community Guyueju for this code project:
https://www.guyuehome.com/34211
