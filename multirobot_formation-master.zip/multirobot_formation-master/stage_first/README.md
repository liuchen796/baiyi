#gazebo中使用

1. 启动gazebo仿真 roslaunch ares_gazebo ares_playground_gazebo.launch
2. 启动跟随程序   roslaunch stage_first OnYourMarkGetSetGo.launch
