^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package multi_jackal_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.5 (2018-02-19)
------------------
* new apriltags, adding pole option for apriltag box, twocams now uses front_flea3
* more tag boxes
* Contributors: Nick Sullivan

0.0.4 (2018-02-13)
------------------

0.0.3 (2018-02-13)
------------------
* licensing, URL's, tutorials updated
* Contributors: Nick Sullivan

0.0.2 (2018-02-12)
------------------
* added nav_msgs dependency
* Contributors: Nick Sullivan

0.0.1 (2018-02-07)
------------------
* Contributors: Nick Sullivan
