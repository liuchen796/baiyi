# DRL_Path_Planning

This is a DRL(Deep Reinforcement Learning) platform built with Gazebo for the purpose of robot's adaptive path planning.

# Environment

## Software

    Ubuntu 16.04
    ROS Kinect
    Python 2.7.12
    tensorflow 1.12.0